"""
EVOLUTION AI DEMO — Car Surface Design Studio
Streamlit + Plotly application for parametric car body design,
surface quality analysis and AI-assisted optimisation.

Features:
  - Bilingual UI (Chinese / English) via I18N dictionary
  - All length sliders display in mm (internal computation in m)
  - Enhanced control-point generation for car-like surfaces
  - Full-car 3D view built geometrically (no algorithm_model dependency)
  - Parts gallery showing individual components
"""
import sys
import os
import copy
import math
from typing import Dict, List, Optional, Tuple

import numpy as np
import streamlit as st
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# ---------------------------------------------------------------------------
# Ensure project root is on sys.path so sibling packages are importable
# ---------------------------------------------------------------------------
_PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

# ---------------------------------------------------------------------------
# Import core modules
# ---------------------------------------------------------------------------
from core.car_surface import (
    CarParams as CoreCarParams,
    generate_car_surfaces,
    assess_quality,
    ai_optimize_surface,
    bezier_surface_vec,
    run_full_pipeline,
    build_side_panel_ctrl,
    build_top_panel_ctrl,
    build_hood_ctrl,
    QualityReport,
    _make_faces,
)

# NOTE: We intentionally do NOT import from algorithm_model so that
# the app works even when that package is unavailable.

# ===================================================================
# I18N — Internationalisation dictionary
# ===================================================================
I18N = {
    "zh": {
        "app_title": "汽车曲面设计工作室",
        "lang_label": "语言",
        # Tabs
        "tab_3d": "3D 视图",
        "tab_opt": "优化对比",
        "tab_quality": "质量分析",
        # Sub-tabs under 3D
        "subtab_surface": "面板曲面",
        "subtab_fullcar": "整车视图",
        "subtab_parts": "零件视图",
        # Sidebar sections
        "section_basic": "📐 基本尺寸",
        "section_styling": "🎨 造型特征",
        "section_ai": "🤖 AI 优化",
        "section_export": "💾 数据导出",
        # Parameters (mm)
        "param_length": "总长 (mm)",
        "param_width": "总宽 (mm)",
        "param_height": "总高 (mm)",
        "param_wheelbase": "轴距 (mm)",
        "param_wheel_arch": "轮拱突出量 (mm)",
        # Parameters (degrees / ratios)
        "param_hood_angle": "引擎盖倾角 (°)",
        "param_roof_arc": "车顶弧度",
        "param_windshield": "前风挡倾角 (°)",
        "param_rear_window": "后风窗倾角 (°)",
        "param_waistline": "腰线高度比",
        # Buttons
        "generate_btn": "生成曲面",
        "optimize_btn": "AI 优化",
        "reset_btn": "重置参数",
        "export_json_btn": "导出 JSON",
        "export_csv_btn": "导出 CSV",
        # Quality
        "quality_title": "曲面质量报告",
        "quality_g0": "G0 连续性",
        "quality_g1": "G1 连续性",
        "quality_g2": "G2 连续性",
        "quality_fairness": "光顺度",
        "quality_overall": "综合评分",
        "quality_notes": "备注",
        # Optimisation
        "opt_before": "优化前",
        "opt_after": "优化后",
        "opt_params_title": "参数对比",
        "opt_quality_title": "质量对比",
        # Surface names
        "surface_side": "侧围面板",
        "surface_top": "顶盖面板",
        "surface_hood": "引擎盖面板",
        # Full car
        "fullcar_title": "整车三维视图",
        "fullcar_no_assembler": "整车视图（几何构建）",
        "fullcar_parts_count": "零件数",
        "fullcar_vertices": "顶点数",
        "fullcar_faces": "面片数",
        # Part names
        "part_side_right": "右侧围",
        "part_side_left": "左侧围",
        "part_top": "顶盖",
        "part_hood": "引擎盖",
        "part_windshield": "前风挡",
        "part_rear_window": "后风窗",
        "part_wheel_fl": "左前轮",
        "part_wheel_fr": "右前轮",
        "part_wheel_rl": "左后轮",
        "part_wheel_rr": "右后轮",
        # Summary
        "param_summary_title": "参数摘要",
        "param_summary_unit": "mm",
        # Misc
        "no_data": "请先点击「生成曲面」",
        "stats_title": "统计信息",
        "export_success": "导出成功！",
    },
    "en": {
        "app_title": "Car Surface Design Studio",
        "lang_label": "Language",
        # Tabs
        "tab_3d": "3D View",
        "tab_opt": "Optimisation",
        "tab_quality": "Quality Analysis",
        # Sub-tabs
        "subtab_surface": "Panel Surfaces",
        "subtab_fullcar": "Full Car View",
        "subtab_parts": "Parts Gallery",
        # Sidebar sections
        "section_basic": "📐 Basic Dimensions",
        "section_styling": "🎨 Styling Features",
        "section_ai": "🤖 AI Optimisation",
        "section_export": "💾 Data Export",
        # Parameters (mm)
        "param_length": "Overall Length (mm)",
        "param_width": "Overall Width (mm)",
        "param_height": "Overall Height (mm)",
        "param_wheelbase": "Wheelbase (mm)",
        "param_wheel_arch": "Wheel Arch Bulge (mm)",
        # Parameters (degrees / ratios)
        "param_hood_angle": "Hood Tilt Angle (°)",
        "param_roof_arc": "Roof Arc Factor",
        "param_windshield": "Windshield Angle (°)",
        "param_rear_window": "Rear Window Angle (°)",
        "param_waistline": "Waistline Height Ratio",
        # Buttons
        "generate_btn": "Generate Surfaces",
        "optimize_btn": "AI Optimise",
        "reset_btn": "Reset Params",
        "export_json_btn": "Export JSON",
        "export_csv_btn": "Export CSV",
        # Quality
        "quality_title": "Surface Quality Report",
        "quality_g0": "G0 Continuity",
        "quality_g1": "G1 Continuity",
        "quality_g2": "G2 Continuity",
        "quality_fairness": "Fairness",
        "quality_overall": "Overall Score",
        "quality_notes": "Notes",
        # Optimisation
        "opt_before": "Before Optimisation",
        "opt_after": "After Optimisation",
        "opt_params_title": "Parameter Comparison",
        "opt_quality_title": "Quality Comparison",
        # Surface names
        "surface_side": "Side Panel",
        "surface_top": "Top Panel",
        "surface_hood": "Hood Panel",
        # Full car
        "fullcar_title": "Full Car 3D View",
        "fullcar_no_assembler": "Full Car View (Geometric Build)",
        "fullcar_parts_count": "Parts",
        "fullcar_vertices": "Vertices",
        "fullcar_faces": "Faces",
        # Part names
        "part_side_right": "Right Side",
        "part_side_left": "Left Side",
        "part_top": "Roof",
        "part_hood": "Hood",
        "part_windshield": "Windshield",
        "part_rear_window": "Rear Window",
        "part_wheel_fl": "FL Wheel",
        "part_wheel_fr": "FR Wheel",
        "part_wheel_rl": "RL Wheel",
        "part_wheel_rr": "RR Wheel",
        # Summary
        "param_summary_title": "Parameter Summary",
        "param_summary_unit": "mm",
        # Misc
        "no_data": "Click 'Generate Surfaces' first",
        "stats_title": "Statistics",
        "export_success": "Export successful!",
    },
}


def t(key: str) -> str:
    """Return translated text for the current language."""
    lang = st.session_state.get("lang", "zh")
    return I18N.get(lang, I18N["zh"]).get(key, key)


# ===================================================================
# Constants: mm slider ranges and defaults
# ===================================================================
# All length values in mm; will be /1000 before passing to CarParams
MM_LENGTH_DEFAULT = 4700
MM_LENGTH_MIN = 3500
MM_LENGTH_MAX = 6000
MM_LENGTH_STEP = 50

MM_WIDTH_DEFAULT = 1850
MM_WIDTH_MIN = 1500
MM_WIDTH_MAX = 2300
MM_WIDTH_STEP = 10

MM_HEIGHT_DEFAULT = 1450
MM_HEIGHT_MIN = 1100
MM_HEIGHT_MAX = 2100
MM_HEIGHT_STEP = 10

MM_WHEELBASE_DEFAULT = 2700
MM_WHEELBASE_MIN = 2000
MM_WHEELBASE_MAX = 3500
MM_WHEELBASE_STEP = 50

MM_WHEEL_ARCH_DEFAULT = 150
MM_WHEEL_ARCH_MIN = 0
MM_WHEEL_ARCH_MAX = 400
MM_WHEEL_ARCH_STEP = 10


# ===================================================================
# Enhanced control-point generators
# ===================================================================

def enhanced_side_panel_ctrl(params) -> np.ndarray:
    """
    Build control points for a realistic side panel.
    Features:
      - Wheel arch depressions at front and rear axle positions
      - Waistline ridge (subtle bulge along the character line)
      - Slight tumble-home (upper body inward lean)
    """
    p = params
    nu, nv = 7, 5
    ctrl = np.zeros((nu, nv, 3))

    half_l = p.length / 2
    half_h = p.height
    y_pos = p.width / 2
    wl_z = p.height * p.waistline_ratio
    wr = p.wheel_radius

    front_axle_x = p.wheelbase / 2
    rear_axle_x = -p.wheelbase / 2

    for i in range(nu):
        for j in range(nv):
            u = i / (nu - 1)
            v = j / (nv - 1)
            x = -half_l + p.length * u

            # Tumble-home: upper body leans inward
            tumble_home = 0.02 * v
            y = y_pos - tumble_home

            # Wheel arch depressions
            for axle_x in [front_axle_x, rear_axle_x]:
                dx = abs(x - axle_x)
                arch_half_w = p.wheel_radius * 1.3
                if dx < arch_half_w and v * half_h < wr * 1.6:
                    arch_depth = ((1 - dx / arch_half_w)
                                  * p.wheel_arch_bulge
                                  * (1 - v * half_h / (wr * 1.6)))
                    y -= arch_depth * 0.5

            # Waistline ridge
            dist_to_wl = abs(v * half_h - wl_z)
            if dist_to_wl < 0.08:
                ridge = 0.012 * (1 - dist_to_wl / 0.08)
                y += ridge

            ctrl[i, j, 0] = x
            ctrl[i, j, 1] = y
            ctrl[i, j, 2] = half_h * v

    return ctrl


def enhanced_top_panel_ctrl(params) -> np.ndarray:
    """
    Build control points for a realistic roof / top panel.
    Features:
      - Smooth arc from windshield header to rear window header
      - Slight crown (cross-car curvature)
      - Front windshield drop and rear window drop
    """
    p = params
    nu, nv = 7, 5
    ctrl = np.zeros((nu, nv, 3))

    half_l = p.length / 2
    base_z = p.height * p.waistline_ratio

    ws_header_x = p.wheelbase / 2 - 0.2
    rw_header_x = -p.wheelbase / 2 + 0.3

    for i in range(nu):
        for j in range(nv):
            u = i / (nu - 1)
            v = j / (nv - 1)
            x = -half_l + p.length * u
            y = -p.width / 2 + p.width * v

            if x > ws_header_x:
                drop_front = ((x - ws_header_x)
                              * np.tan(np.radians(p.windshield_angle)) * 0.6)
                z = base_z + p.height * (1 - p.waistline_ratio) * p.roof_arc - drop_front
            elif x < rw_header_x:
                drop_rear = ((rw_header_x - x)
                             * np.tan(np.radians(p.rear_window_angle)) * 0.4)
                z = base_z + p.height * (1 - p.waistline_ratio) * p.roof_arc - drop_rear
            else:
                centre_x = (ws_header_x + rw_header_x) / 2
                span = (ws_header_x - rw_header_x) / 2
                if span > 0:
                    arc_factor = 1 - ((x - centre_x) / span) ** 2
                else:
                    arc_factor = 0
                z = (base_z
                     + p.height * (1 - p.waistline_ratio)
                     * (p.roof_arc * 0.3 + 0.7 * arc_factor * p.roof_arc))

            # Cross-car crown
            v_centre = 0.5
            crown = 0.015 * (1 - (2 * (v - v_centre)) ** 2)
            z += crown

            ctrl[i, j, 0] = x
            ctrl[i, j, 1] = y
            ctrl[i, j, 2] = z

    return ctrl


def enhanced_hood_ctrl(params) -> np.ndarray:
    """
    Build control points for a realistic hood panel.
    Features:
      - Front edge dips down (hood tilt angle)
      - Central power-bulge
      - Slight taper towards the front
    """
    p = params
    nu, nv = 6, 5
    ctrl = np.zeros((nu, nv, 3))

    front_axle_x = p.wheelbase / 2
    hood_start_x = front_axle_x - 0.15
    hood_end_x = hood_start_x + p.front_overhang
    base_z = p.height * p.waistline_ratio + 0.04

    for i in range(nu):
        for j in range(nv):
            u = i / (nu - 1)
            v = j / (nv - 1)
            x = hood_start_x + (hood_end_x - hood_start_x) * u

            dip = u * (hood_end_x - hood_start_x) * np.tan(np.radians(p.hood_angle)) * 0.5
            v_off = abs(v - 0.5)
            bulge = 0.02 * (1 - (2 * v_off) ** 2) * (1 - u)

            taper = 1 - 0.08 * u
            y = -p.width / 2 * taper + p.width * taper * v

            ctrl[i, j, 0] = x
            ctrl[i, j, 1] = y
            ctrl[i, j, 2] = base_z - dip + bulge

    return ctrl


# ===================================================================
# Geometric construction helpers for full-car view
# ===================================================================

def build_windshield_surface(params) -> dict:
    """
    Build a Bezier surface for the front windshield.
    The windshield spans from the hood front edge up to the roof header,
    tilted by windshield_angle.
    Returns {"vertices": np.ndarray, "faces": np.ndarray}.
    """
    p = params
    nu, nv = 5, 4
    ctrl = np.zeros((nu, nv, 3))

    # Bottom edge: front of car at hood height
    hood_front_x = p.wheelbase / 2 + p.front_overhang * 0.6
    hood_z = p.height * p.waistline_ratio + 0.04

    # Top edge: windshield header, further back and higher
    ws_header_x = p.wheelbase / 2 - 0.2
    roof_z = p.height * p.waistline_ratio + p.height * (1 - p.waistline_ratio) * p.roof_arc

    width = p.width * 0.92  # slightly narrower than body

    for i in range(nu):
        for j in range(nv):
            # u: 0=bottom, 1=top
            u = i / (nu - 1)
            # v: 0=left, 1=right
            v = j / (nv - 1)

            x = hood_front_x + (ws_header_x - hood_front_x) * u
            y = -width / 2 + width * v
            z = hood_z + (roof_z - hood_z) * u

            # Slight curvature: bow outward
            bow = 0.03 * np.sin(u * np.pi) * (1 - abs(2 * v - 1) ** 2)
            z += bow

            ctrl[i, j, 0] = x
            ctrl[i, j, 1] = y
            ctrl[i, j, 2] = z

    verts = bezier_surface_vec(ctrl, p.surface_u, p.surface_v)
    faces = _make_faces(p.surface_u, p.surface_v)
    return {"vertices": verts, "faces": faces}


def build_rear_window_surface(params) -> dict:
    """
    Build a Bezier surface for the rear window.
    The rear window spans from the roof rear edge down to the trunk,
    tilted by rear_window_angle.
    Returns {"vertices": np.ndarray, "faces": np.ndarray}.
    """
    p = params
    nu, nv = 5, 4
    ctrl = np.zeros((nu, nv, 3))

    # Top edge: rear roof header
    rw_header_x = -p.wheelbase / 2 + 0.3
    roof_z = p.height * p.waistline_ratio + p.height * (1 - p.waistline_ratio) * p.roof_arc

    # Bottom edge: rear of car at trunk height
    rear_x = -p.wheelbase / 2 - p.rear_overhang * 0.6
    trunk_z = p.height * p.waistline_ratio + 0.02

    width = p.width * 0.88

    for i in range(nu):
        for j in range(nv):
            # u: 0=top, 1=bottom
            u = i / (nu - 1)
            v = j / (nv - 1)

            x = rw_header_x + (rear_x - rw_header_x) * u
            y = -width / 2 + width * v
            z = roof_z + (trunk_z - roof_z) * u

            # Curvature
            bow = 0.025 * np.sin(u * np.pi) * (1 - abs(2 * v - 1) ** 2)
            z += bow

            ctrl[i, j, 0] = x
            ctrl[i, j, 1] = y
            ctrl[i, j, 2] = z

    verts = bezier_surface_vec(ctrl, p.surface_u, p.surface_v)
    faces = _make_faces(p.surface_u, p.surface_v)
    return {"vertices": verts, "faces": faces}


def build_wheel_mesh(cx: float, cy: float, cz: float,
                     radius: float, width: float,
                     n_seg: int = 24) -> dict:
    """
    Generate a wheel mesh (cylinder + end caps) centred at (cx, cy, cz).

    The wheel axis is along Y. The cylinder has n_seg segments around.
    Returns {"vertices": np.ndarray, "faces": np.ndarray}.
    """
    half_w = width / 2
    verts = []
    faces = []

    # Ring points at y = -half_w and y = +half_w
    for ring_idx in range(2):
        y_off = -half_w + ring_idx * width
        for s in range(n_seg):
            angle = 2 * math.pi * s / n_seg
            vx = cx + radius * math.cos(angle)
            vy = cy + y_off
            vz = cz + radius * math.sin(angle)
            verts.append([vx, vy, vz])

    # Side faces: connect the two rings
    for s in range(n_seg):
        s_next = (s + 1) % n_seg
        p0 = s            # ring 0
        p1 = s_next       # ring 0
        p2 = s + n_seg    # ring 1
        p3 = s_next + n_seg  # ring 1
        faces.append([p0, p2, p3])
        faces.append([p0, p3, p1])

    # End caps: use centre point
    # Left cap centre
    verts.append([cx, cy - half_w, cz])
    left_center = len(verts) - 1
    for s in range(n_seg):
        s_next = (s + 1) % n_seg
        faces.append([left_center, s_next, s])

    # Right cap centre
    verts.append([cx, cy + half_w, cz])
    right_center = len(verts) - 1
    for s in range(n_seg):
        s_next = (s + 1) % n_seg
        faces.append([right_center, s + n_seg, s_next + n_seg])

    # Add hub (inner disc for realism)
    hub_r = radius * 0.35
    for ring_idx in range(2):
        y_off = -half_w * 0.95 + ring_idx * width * 0.9
        for s in range(n_seg):
            angle = 2 * math.pi * s / n_seg
            vx = cx + hub_r * math.cos(angle)
            vy = cy + y_off
            vz = cz + hub_r * math.sin(angle)
            verts.append([vx, vy, vz])

    hub_offset = 2 * n_seg + 2  # after main ring points and two centres
    for ring_idx in range(2):
        base = hub_offset + ring_idx * n_seg
        centre_idx = left_center if ring_idx == 0 else right_center
        for s in range(n_seg):
            s_next = (s + 1) % n_seg
            if ring_idx == 0:
                # Left hub: normals point inward (-y)
                faces.append([centre_idx, base + s, base + s_next])
            else:
                # Right hub: normals point outward (+y)
                faces.append([centre_idx, base + s_next, base + s])

    return {
        "vertices": np.array(verts, dtype=np.float64),
        "faces": np.array(faces, dtype=np.int64),
    }


def mirror_surface_xz(surf: dict) -> dict:
    """
    Mirror a surface across the XZ plane (flip Y coordinates).
    Used to create the left side from the right side panel.
    """
    verts = surf["vertices"].copy()
    verts[:, 1] = -verts[:, 1]
    # Flip face winding for correct normals
    faces = surf["faces"].copy()
    faces[:, [1, 2]] = faces[:, [2, 1]]
    return {"vertices": verts, "faces": faces}


# ===================================================================
# Plotly helpers
# ===================================================================

def surface_dict_to_plotly(surf: dict, name: str = "surface",
                           color: str = "royalblue",
                           opacity: float = 0.8) -> go.Mesh3d:
    """Convert a surface dict {vertices, faces} to a Plotly mesh3d trace."""
    verts = surf["vertices"]
    faces = surf["faces"]
    return go.Mesh3d(
        x=verts[:, 0],
        y=verts[:, 1],
        z=verts[:, 2],
        i=faces[:, 0],
        j=faces[:, 1],
        k=faces[:, 2],
        name=name,
        color=color,
        opacity=opacity,
        flatshading=True,
    )


def _3d_layout(title: str = "", unit_label: str = "m") -> go.Layout:
    """Return a standard 3D layout with equal aspect ratio and rotation."""
    return go.Layout(
        title=title,
        scene=dict(
            aspectmode="data",
            xaxis=dict(title=f"X ({unit_label})"),
            yaxis=dict(title=f"Y ({unit_label})"),
            zaxis=dict(title=f"Z ({unit_label})"),
            camera=dict(eye=dict(x=1.8, y=1.8, z=1.2)),
        ),
        margin=dict(l=0, r=0, t=40, b=0),
        height=600,
    )


def _mini_3d_layout(title: str = "") -> go.Layout:
    """Compact 3D layout for small part previews."""
    return go.Layout(
        title=dict(text=title, font=dict(size=11)),
        scene=dict(
            aspectmode="data",
            xaxis=dict(showticklabels=False, visible=False),
            yaxis=dict(showticklabels=False, visible=False),
            zaxis=dict(showticklabels=False, visible=False),
            camera=dict(eye=dict(x=1.5, y=1.5, z=1.0)),
        ),
        margin=dict(l=0, r=0, t=30, b=0),
        height=250,
    )


# ===================================================================
# Surface generation with enhanced control points
# ===================================================================

def generate_enhanced_surfaces(params) -> Dict[str, dict]:
    """
    Generate three car surfaces using enhanced control-point builders.
    Falls back to the original builders on error.
    """
    builders = {
        "side": enhanced_side_panel_ctrl,
        "top": enhanced_top_panel_ctrl,
        "hood": enhanced_hood_ctrl,
    }
    fallback = {
        "side": build_side_panel_ctrl,
        "top": build_top_panel_ctrl,
        "hood": build_hood_ctrl,
    }
    result = {}
    for name, builder in builders.items():
        try:
            ctrl = builder(params)
            verts = bezier_surface_vec(ctrl, params.surface_u, params.surface_v)
            faces = _make_faces(params.surface_u, params.surface_v)
        except Exception:
            ctrl = fallback[name](params)
            verts = bezier_surface_vec(ctrl, params.surface_u, params.surface_v)
            faces = _make_faces(params.surface_u, params.surface_v)
        result[name] = {"vertices": verts, "faces": faces}
    return result


# ===================================================================
# Full-car geometric builder (no algorithm_model dependency)
# ===================================================================

def build_full_car_geometric(params) -> Dict[str, dict]:
    """
    Build all car parts geometrically from params.
    Returns a dict mapping part names to surface dicts.
    Parts: side_right, side_left, top, hood, windshield, rear_window,
           wheel_fl, wheel_fr, wheel_rl, wheel_rr
    """
    # Generate the three main surfaces
    base_surfaces = generate_enhanced_surfaces(params)

    parts = {}
    # Side panels: right side (original) and left side (mirrored)
    parts["side_right"] = base_surfaces["side"]
    parts["side_left"] = mirror_surface_xz(base_surfaces["side"])

    # Top panel and hood (already correctly positioned)
    parts["top"] = base_surfaces["top"]
    parts["hood"] = base_surfaces["hood"]

    # Windshield and rear window
    parts["windshield"] = build_windshield_surface(params)
    parts["rear_window"] = build_rear_window_surface(params)

    # Wheels
    wr = params.wheel_radius
    wheel_width = 0.20  # approximate tire width in m
    front_x = params.wheelbase / 2
    rear_x = -params.wheelbase / 2
    side_y_right = params.width / 2 + 0.05  # slightly outside body
    side_y_left = -(params.width / 2 + 0.05)
    wheel_z = wr  # wheel centre sits at radius height

    parts["wheel_fr"] = build_wheel_mesh(front_x, side_y_right, wheel_z,
                                          wr, wheel_width)
    parts["wheel_fl"] = build_wheel_mesh(front_x, side_y_left, wheel_z,
                                          wr, wheel_width)
    parts["wheel_rr"] = build_wheel_mesh(rear_x, side_y_right, wheel_z,
                                          wr, wheel_width)
    parts["wheel_rl"] = build_wheel_mesh(rear_x, side_y_left, wheel_z,
                                          wr, wheel_width)

    return parts


# ===================================================================
# Parameter widget helpers
# ===================================================================

def _mm_slider(label_key: str, min_val: int, max_val: int,
               default: int, step: int = 10) -> int:
    """Render a Streamlit slider for mm values (integer)."""
    return st.sidebar.slider(
        t(label_key), min_val, max_val, default, step, format="%d"
    )


def read_params_from_sidebar() -> CoreCarParams:
    """Read all car parameters from sidebar sliders and return CoreCarParams.
    Length sliders display in mm; values are converted to m internally."""

    # --- Basic dimensions section ---
    st.sidebar.markdown(f"**{t('section_basic')}**")

    length_mm = _mm_slider("param_length",
                           MM_LENGTH_MIN, MM_LENGTH_MAX,
                           MM_LENGTH_DEFAULT, MM_LENGTH_STEP)
    width_mm = _mm_slider("param_width",
                          MM_WIDTH_MIN, MM_WIDTH_MAX,
                          MM_WIDTH_DEFAULT, MM_WIDTH_STEP)
    height_mm = _mm_slider("param_height",
                           MM_HEIGHT_MIN, MM_HEIGHT_MAX,
                           MM_HEIGHT_DEFAULT, MM_HEIGHT_STEP)
    wheelbase_mm = _mm_slider("param_wheelbase",
                              MM_WHEELBASE_MIN, MM_WHEELBASE_MAX,
                              MM_WHEELBASE_DEFAULT, MM_WHEELBASE_STEP)

    # --- Styling features section ---
    st.sidebar.markdown(f"**{t('section_styling')}**")

    wheel_arch_mm = _mm_slider("param_wheel_arch",
                               MM_WHEEL_ARCH_MIN, MM_WHEEL_ARCH_MAX,
                               MM_WHEEL_ARCH_DEFAULT, MM_WHEEL_ARCH_STEP)

    hood_angle = st.sidebar.slider(t("param_hood_angle"), 0.0, 35.0, 15.0, 0.5,
                                   format="%.1f")
    roof_arc = st.sidebar.slider(t("param_roof_arc"), 0.0, 1.5, 0.5, 0.01,
                                 format="%.2f")
    windshield = st.sidebar.slider(t("param_windshield"), 15.0, 45.0, 28.0, 0.5,
                                   format="%.1f")
    rear_window = st.sidebar.slider(t("param_rear_window"), 10.0, 40.0, 25.0, 0.5,
                                    format="%.1f")
    waistline = st.sidebar.slider(t("param_waistline"), 0.5, 0.95, 0.75, 0.01,
                                  format="%.2f")

    # Convert mm to m for internal computation
    length_m = length_mm / 1000.0
    width_m = width_mm / 1000.0
    height_m = height_mm / 1000.0
    wheelbase_m = wheelbase_mm / 1000.0
    wheel_arch_m = wheel_arch_mm / 1000.0

    # Derive overhangs from length & wheelbase
    total_oh = length_m - wheelbase_m
    front_oh = round(total_oh * 0.45, 3)
    rear_oh = round(total_oh - front_oh, 3)

    return CoreCarParams(
        length=length_m,
        width=width_m,
        height=height_m,
        wheelbase=wheelbase_m,
        front_overhang=front_oh,
        rear_overhang=rear_oh,
        hood_angle=hood_angle,
        roof_arc=roof_arc,
        windshield_angle=windshield,
        rear_window_angle=rear_window,
        wheel_arch_bulge=wheel_arch_m,
        waistline_ratio=waistline,
    )


def render_param_summary(params: CoreCarParams):
    """Render a compact parameter summary showing values in mm."""
    st.sidebar.markdown("---")
    st.sidebar.markdown(f"**{t('param_summary_title')}** ({t('param_summary_unit')})")

    summary_items = [
        (t("param_length"), f"{params.length * 1000:.0f}"),
        (t("param_width"), f"{params.width * 1000:.0f}"),
        (t("param_height"), f"{params.height * 1000:.0f}"),
        (t("param_wheelbase"), f"{params.wheelbase * 1000:.0f}"),
        (t("param_wheel_arch"), f"{params.wheel_arch_bulge * 1000:.0f}"),
        (t("param_hood_angle"), f"{params.hood_angle:.1f}°"),
        (t("param_roof_arc"), f"{params.roof_arc:.2f}"),
        (t("param_windshield"), f"{params.windshield_angle:.1f}°"),
        (t("param_rear_window"), f"{params.rear_window_angle:.1f}°"),
        (t("param_waistline"), f"{params.waistline_ratio:.2f}"),
    ]
    for label, val in summary_items:
        st.sidebar.text(f"{label}: {val}")


# ===================================================================
# Tab renderers
# ===================================================================

def render_panel_surfaces_subtab(surfaces: Optional[Dict[str, dict]]):
    """Render the Panel Surfaces sub-tab."""
    if surfaces is None:
        st.info(t("no_data"))
        return

    surface_colors = {
        "side": ("surface_side", "#4A90D9"),
        "top": ("surface_top", "#50C878"),
        "hood": ("surface_hood", "#E8A838"),
    }
    traces = []
    for key, (label_key, color) in surface_colors.items():
        if key in surfaces:
            traces.append(surface_dict_to_plotly(
                surfaces[key], name=t(label_key), color=color, opacity=0.85
            ))
    fig = go.Figure(data=traces, layout=_3d_layout(t("app_title")))
    st.plotly_chart(fig, use_container_width=True)

    # Surface statistics
    with st.expander(t("stats_title")):
        for key in surfaces:
            v_count = len(surfaces[key]["vertices"])
            f_count = len(surfaces[key]["faces"])
            label_key = "surface_" + key
            st.write(f"**{t(label_key)}**: {v_count} vertices, {f_count} faces")


def render_full_car_subtab(params: CoreCarParams):
    """Render the Full Car View sub-tab with geometric build."""
    parts = build_full_car_geometric(params)

    # Color scheme for each part
    part_styles = {
        "side_right":  ("#4A90D9", 0.85),
        "side_left":   ("#4A90D9", 0.85),
        "top":         ("#50C878", 0.85),
        "hood":        ("#E8A838", 0.85),
        "windshield":  ("#87CEEB", 0.50),
        "rear_window": ("#87CEEB", 0.50),
        "wheel_fr":    ("#333333", 0.95),
        "wheel_fl":    ("#333333", 0.95),
        "wheel_rr":    ("#333333", 0.95),
        "wheel_rl":    ("#333333", 0.95),
    }

    part_label_keys = {
        "side_right":  "part_side_right",
        "side_left":   "part_side_left",
        "top":         "part_top",
        "hood":        "part_hood",
        "windshield":  "part_windshield",
        "rear_window": "part_rear_window",
        "wheel_fr":    "part_wheel_fr",
        "wheel_fl":    "part_wheel_fl",
        "wheel_rr":    "part_wheel_rr",
        "wheel_rl":    "part_wheel_rl",
    }

    traces = []
    for part_name, surf in parts.items():
        color, opacity = part_styles.get(part_name, ("#888888", 0.8))
        label_key = part_label_keys.get(part_name, part_name)
        traces.append(surface_dict_to_plotly(
            surf, name=t(label_key), color=color, opacity=opacity
        ))

    fig = go.Figure(data=traces, layout=_3d_layout(t("fullcar_title")))
    st.plotly_chart(fig, use_container_width=True)

    # Statistics
    total_verts = sum(len(p["vertices"]) for p in parts.values())
    total_faces = sum(len(p["faces"]) for p in parts.values())
    col1, col2, col3 = st.columns(3)
    col1.metric(t("fullcar_parts_count"), f"{len(parts)}")
    col2.metric(t("fullcar_vertices"), f"{total_verts}")
    col3.metric(t("fullcar_faces"), f"{total_faces}")


def render_parts_gallery_subtab(params: CoreCarParams):
    """Render the Parts Gallery sub-tab with individual part previews."""
    parts = build_full_car_geometric(params)

    # Part display order and styles
    part_configs = [
        ("side_right",  "part_side_right",  "#4A90D9", 0.90),
        ("side_left",   "part_side_left",   "#5B9BD5", 0.90),
        ("top",         "part_top",         "#50C878", 0.90),
        ("hood",        "part_hood",        "#E8A838", 0.90),
        ("windshield",  "part_windshield",  "#87CEEB", 0.60),
        ("rear_window", "part_rear_window", "#6EC6FF", 0.60),
        ("wheel_fr",    "part_wheel_fr",    "#333333", 0.95),
        ("wheel_fl",    "part_wheel_fl",    "#444444", 0.95),
        ("wheel_rr",    "part_wheel_rr",    "#555555", 0.95),
        ("wheel_rl",    "part_wheel_rl",    "#666666", 0.95),
    ]

    # Grid layout: 5 columns x 2 rows
    cols_per_row = 5
    for row_start in range(0, len(part_configs), cols_per_row):
        row_parts = part_configs[row_start:row_start + cols_per_row]
        columns = st.columns(cols_per_row)
        for idx, (part_name, label_key, color, opacity) in enumerate(row_parts):
            with columns[idx]:
                if part_name in parts:
                    surf = parts[part_name]
                    trace = surface_dict_to_plotly(
                        surf, name=t(label_key), color=color, opacity=opacity
                    )
                    fig = go.Figure(
                        data=[trace],
                        layout=_mini_3d_layout(t(label_key))
                    )
                    st.plotly_chart(fig, use_container_width=True)


def render_3d_tab(params: CoreCarParams, surfaces: Optional[Dict[str, dict]]):
    """Render the 3D View tab with three sub-tabs."""
    sub_tabs = st.tabs([
        t("subtab_surface"),
        t("subtab_fullcar"),
        t("subtab_parts"),
    ])

    with sub_tabs[0]:
        render_panel_surfaces_subtab(surfaces)

    with sub_tabs[1]:
        render_full_car_subtab(params)

    with sub_tabs[2]:
        render_parts_gallery_subtab(params)


def render_optimisation_tab(params: CoreCarParams,
                            surfaces: Optional[Dict[str, dict]]):
    """Render the Optimisation Comparison tab."""
    if surfaces is None:
        st.info(t("no_data"))
        return

    if st.button(t("optimize_btn"), key="opt_btn"):
        with st.spinner("AI optimising..." if st.session_state.get("lang", "zh") == "en"
                        else "AI 优化中..."):
            opt_params, opt_surfaces, opt_report = ai_optimize_surface(params, surfaces)
        st.session_state["opt_params"] = opt_params
        st.session_state["opt_surfaces"] = opt_surfaces
        st.session_state["opt_report"] = opt_report

    opt_surfaces = st.session_state.get("opt_surfaces")
    opt_report = st.session_state.get("opt_report")
    opt_params = st.session_state.get("opt_params")

    if opt_surfaces is None:
        return

    # --- Parameter comparison ---
    st.subheader(t("opt_params_title"))
    orig_report = assess_quality(surfaces)

    param_fields = [
        ("length", "param_length"),
        ("width", "param_width"),
        ("height", "param_height"),
        ("wheelbase", "param_wheelbase"),
        ("hood_angle", "param_hood_angle"),
        ("roof_arc", "param_roof_arc"),
        ("windshield_angle", "param_windshield"),
        ("rear_window_angle", "param_rear_window"),
        ("wheel_arch_bulge", "param_wheel_arch"),
        ("waistline_ratio", "param_waistline"),
    ]

    col_before, col_after = st.columns(2)
    with col_before:
        st.markdown(f"**{t('opt_before')}**")
        for attr, label_key in param_fields:
            val = getattr(params, attr, "—")
            # Show length values in mm
            if attr in ("length", "width", "height", "wheelbase", "wheel_arch_bulge"):
                val = f"{val * 1000:.0f}"
            st.write(f"{t(label_key)}: {val}")

    with col_after:
        st.markdown(f"**{t('opt_after')}**")
        for attr, label_key in param_fields:
            val = getattr(opt_params, attr, "—")
            if attr in ("length", "width", "height", "wheelbase", "wheel_arch_bulge"):
                val = f"{val * 1000:.0f}"
            st.write(f"{t(label_key)}: {val}")

    # --- Quality comparison ---
    st.subheader(t("opt_quality_title"))
    quality_fields = [
        ("g0_continuity", "quality_g0"),
        ("g1_continuity", "quality_g1"),
        ("g2_continuity", "quality_g2"),
        ("fairness", "quality_fairness"),
        ("overall_score", "quality_overall"),
    ]

    col_q1, col_q2 = st.columns(2)
    with col_q1:
        st.markdown(f"**{t('opt_before')}**")
        for attr, label_key in quality_fields:
            val = getattr(orig_report, attr, 0)
            st.progress(min(val, 1.0), text=f"{t(label_key)}: {val:.3f}")

    with col_q2:
        st.markdown(f"**{t('opt_after')}**")
        for attr, label_key in quality_fields:
            val = getattr(opt_report, attr, 0)
            st.progress(min(val, 1.0), text=f"{t(label_key)}: {val:.3f}")

    # --- 3D comparison ---
    surface_colors = {"side": "#4A90D9", "top": "#50C878", "hood": "#E8A838"}
    col_3d1, col_3d2 = st.columns(2)

    with col_3d1:
        traces_before = []
        for key, color in surface_colors.items():
            if key in surfaces:
                traces_before.append(surface_dict_to_plotly(
                    surfaces[key], name=key, color=color, opacity=0.8))
        fig_before = go.Figure(data=traces_before,
                               layout=_3d_layout(t("opt_before")))
        st.plotly_chart(fig_before, use_container_width=True)

    with col_3d2:
        traces_after = []
        for key, color in surface_colors.items():
            if key in opt_surfaces:
                traces_after.append(surface_dict_to_plotly(
                    opt_surfaces[key], name=key, color=color, opacity=0.8))
        fig_after = go.Figure(data=traces_after,
                              layout=_3d_layout(t("opt_after")))
        st.plotly_chart(fig_after, use_container_width=True)


def render_quality_tab(surfaces: Optional[Dict[str, dict]]):
    """Render the Quality Analysis tab."""
    if surfaces is None:
        st.info(t("no_data"))
        return

    report = assess_quality(surfaces)

    st.subheader(t("quality_title"))

    # Radar chart
    categories = [
        t("quality_g0"), t("quality_g1"), t("quality_g2"),
        t("quality_fairness"), t("quality_overall"),
    ]
    values = [
        report.g0_continuity, report.g1_continuity, report.g2_continuity,
        report.fairness, report.overall_score,
    ]
    categories_closed = categories + [categories[0]]
    values_closed = values + [values[0]]

    fig_radar = go.Figure(data=go.Scatterpolar(
        r=values_closed,
        theta=categories_closed,
        fill="toself",
        name=t("quality_title"),
    ))
    fig_radar.update_layout(
        polar=dict(radialaxis=dict(visible=True, range=[0, 1])),
        showlegend=False,
        height=450,
    )
    st.plotly_chart(fig_radar, use_container_width=True)

    # Detailed metrics
    quality_fields = [
        ("g0_continuity", "quality_g0"),
        ("g1_continuity", "quality_g1"),
        ("g2_continuity", "quality_g2"),
        ("fairness", "quality_fairness"),
        ("overall_score", "quality_overall"),
    ]
    for attr, label_key in quality_fields:
        val = getattr(report, attr, 0)
        st.progress(min(val, 1.0), text=f"{t(label_key)}: {val:.4f}")

    if report.notes:
        st.info(f"**{t('quality_notes')}**: {report.notes}")


def render_export_section(params: CoreCarParams,
                          surfaces: Optional[Dict[str, dict]]):
    """Render the data export buttons in the sidebar."""
    st.sidebar.markdown(f"**{t('section_export')}**")

    if st.sidebar.button(t("export_json_btn"), key="export_json"):
        import json
        export_data = {
            "params": {
                "length_mm": params.length * 1000,
                "width_mm": params.width * 1000,
                "height_mm": params.height * 1000,
                "wheelbase_mm": params.wheelbase * 1000,
                "hood_angle": params.hood_angle,
                "roof_arc": params.roof_arc,
                "windshield_angle": params.windshield_angle,
                "rear_window_angle": params.rear_window_angle,
                "wheel_arch_bulge_mm": params.wheel_arch_bulge * 1000,
                "waistline_ratio": params.waistline_ratio,
            }
        }
        if surfaces:
            export_data["surface_count"] = len(surfaces)
            for k, v in surfaces.items():
                export_data[f"{k}_vertices"] = len(v["vertices"])
                export_data[f"{k}_faces"] = len(v["faces"])

        json_str = json.dumps(export_data, indent=2, ensure_ascii=False)
        st.sidebar.download_button(
            label="⬇ JSON",
            data=json_str,
            file_name="car_params.json",
            mime="application/json",
            key="dl_json",
        )

    if st.sidebar.button(t("export_csv_btn"), key="export_csv"):
        import io
        output = io.StringIO()
        output.write("parameter,value_mm\n")
        output.write(f"length,{params.length * 1000:.0f}\n")
        output.write(f"width,{params.width * 1000:.0f}\n")
        output.write(f"height,{params.height * 1000:.0f}\n")
        output.write(f"wheelbase,{params.wheelbase * 1000:.0f}\n")
        output.write(f"wheel_arch_bulge,{params.wheel_arch_bulge * 1000:.0f}\n")
        output.write(f"hood_angle,{params.hood_angle:.1f}\n")
        output.write(f"roof_arc,{params.roof_arc:.2f}\n")
        output.write(f"windshield_angle,{params.windshield_angle:.1f}\n")
        output.write(f"rear_window_angle,{params.rear_window_angle:.1f}\n")
        output.write(f"waistline_ratio,{params.waistline_ratio:.2f}\n")
        csv_str = output.getvalue()
        st.sidebar.download_button(
            label="⬇ CSV",
            data=csv_str,
            file_name="car_params.csv",
            mime="text/csv",
            key="dl_csv",
        )


# ===================================================================
# Main application
# ===================================================================

def main():
    """Entry point for the Streamlit application."""

    # --- Page config ---
    st.set_page_config(
        page_title="EVOLUTION AI DEMO",
        page_icon="🚗",
        layout="wide",
    )

    # --- Language selector persisted in session_state ---
    if "lang" not in st.session_state:
        st.session_state["lang"] = "zh"

    # --- Title + language switch on the same row ---
    title_col, lang_col = st.columns([4, 1])
    with title_col:
        st.title(t("app_title"))
    with lang_col:
        st.markdown("<br>", unsafe_allow_html=True)  # align with title
        lang_choice = st.selectbox(
            t("lang_label"),
            options=["zh", "en"],
            index=0 if st.session_state["lang"] == "zh" else 1,
            key="lang_selector",
            label_visibility="collapsed" if st.session_state["lang"] == "zh" else "visible",
        )
        st.session_state["lang"] = lang_choice

    # --- Sidebar: Parameters ---
    st.sidebar.header(t("param_section"))
    params = read_params_from_sidebar()

    # --- Sidebar: AI optimisation section ---
    st.sidebar.markdown(f"**{t('section_ai')}**")

    # --- Action buttons ---
    col_gen, col_rst = st.sidebar.columns(2)
    generate_clicked = col_gen.button(t("generate_btn"), key="gen_btn_sidebar",
                                      use_container_width=True)
    reset_clicked = col_rst.button(t("reset_btn"), key="rst_btn_sidebar",
                                    use_container_width=True)

    if reset_clicked:
        for k in list(st.session_state.keys()):
            if k not in ("lang", "lang_selector"):
                del st.session_state[k]
        st.rerun()

    # --- Parameter summary ---
    render_param_summary(params)

    # --- Export section ---
    render_export_section(params, st.session_state.get("surfaces"))

    # --- Generate surfaces ---
    if generate_clicked or "surfaces" in st.session_state:
        if generate_clicked:
            with st.spinner("Generating..." if st.session_state["lang"] == "en"
                            else "生成中..."):
                st.session_state["surfaces"] = generate_enhanced_surfaces(params)
                st.session_state["params_snapshot"] = copy.deepcopy(params)
                # Clear stale optimisation data
                for k in ("opt_params", "opt_surfaces", "opt_report"):
                    st.session_state.pop(k, None)

        surfaces = st.session_state.get("surfaces")
        active_params = st.session_state.get("params_snapshot", params)
    else:
        surfaces = None
        active_params = params

    # --- Main tabs ---
    tab_3d, tab_opt, tab_quality = st.tabs([
        t("tab_3d"), t("tab_opt"), t("tab_quality")
    ])

    with tab_3d:
        render_3d_tab(active_params, surfaces)

    with tab_opt:
        render_optimisation_tab(active_params, surfaces)

    with tab_quality:
        render_quality_tab(surfaces)


# ===================================================================
# Entry point
# ===================================================================
if __name__ == "__main__":
    main()
