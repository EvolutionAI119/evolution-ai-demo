"""
EVOLUTION AI DEMO — Car Surface Design Studio
Streamlit + Plotly application for parametric car body design,
surface quality analysis and AI-assisted optimisation.

Features:
  - Bilingual UI (Chinese / English) via I18N dictionary
  - Expanded realistic parameter ranges
  - Enhanced control-point generation for car-like surfaces
  - Full-car 3D view using assembler module with Plotly mesh3d
"""
import sys
import os
import copy
from typing import Dict, Optional, Tuple

import numpy as np
import streamlit as st
import plotly.graph_objects as go

# ---------------------------------------------------------------------------
# Ensure project root is on sys.path so sibling packages are importable
# ---------------------------------------------------------------------------
_PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

# ---------------------------------------------------------------------------
# Import core modules
# ---------------------------------------------------------------------------
from core.car_surface import (
    CarParams as CoreCarParams,
    generate_car_surfaces,
    assess_quality,
    ai_optimize_surface,
    bezier_surface_vec,
    run_full_pipeline,
    build_side_panel_ctrl,
    build_top_panel_ctrl,
    build_hood_ctrl,
    QualityReport,
)

try:
    from algorithm_model.car_modeling.assembler import build_full_car, merge_all
    from algorithm_model.car_modeling.car_params import CarParams as FullCarParams
    _HAS_ASSEMBLER = True
except ImportError:
    _HAS_ASSEMBLER = False

# ===================================================================
# I18N — Internationalisation dictionary
# ===================================================================
I18N = {
    "zh": {
        "app_title": "汽车曲面设计工作室",
        "lang_label": "语言 / Language",
        "tab_3d": "3D 视图",
        "tab_opt": "优化对比",
        "tab_quality": "质量分析",
        "subtab_surface": "面板曲面",
        "subtab_fullcar": "整车视图",
        "param_section": "车身参数",
        "param_length": "总长 (m)",
        "param_width": "总宽 (m)",
        "param_height": "总高 (m)",
        "param_wheelbase": "轴距 (m)",
        "param_hood_angle": "引擎盖倾角 (°)",
        "param_roof_arc": "车顶弧度",
        "param_windshield": "前风挡倾角 (°)",
        "param_rear_window": "后风窗倾角 (°)",
        "param_wheel_arch": "轮拱突出量 (m)",
        "param_waistline": "腰线高度比",
        "generate_btn": "生成曲面",
        "optimize_btn": "AI 优化",
        "reset_btn": "重置参数",
        "quality_title": "曲面质量报告",
        "quality_g0": "G0 连续性",
        "quality_g1": "G1 连续性",
        "quality_g2": "G2 连续性",
        "quality_fairness": "光顺度",
        "quality_overall": "综合评分",
        "quality_notes": "备注",
        "opt_before": "优化前",
        "opt_after": "优化后",
        "opt_params_title": "参数对比",
        "opt_quality_title": "质量对比",
        "surface_side": "侧围面板",
        "surface_top": "顶盖面板",
        "surface_hood": "引擎盖面板",
        "fullcar_title": "整车三维视图",
        "fullcar_fallback": "整车模块不可用，已切换到三面板合并视图",
        "fullcar_parts_count": "零件数",
        "fullcar_vertices": "顶点数",
        "fullcar_faces": "面片数",
        "no_data": "请先点击「生成曲面」",
        "stats_title": "统计信息",
    },
    "en": {
        "app_title": "Car Surface Design Studio",
        "lang_label": "Language / 语言",
        "tab_3d": "3D View",
        "tab_opt": "Optimisation",
        "tab_quality": "Quality Analysis",
        "subtab_surface": "Panel Surfaces",
        "subtab_fullcar": "Full Car View",
        "param_section": "Body Parameters",
        "param_length": "Overall Length (m)",
        "param_width": "Overall Width (m)",
        "param_height": "Overall Height (m)",
        "param_wheelbase": "Wheelbase (m)",
        "param_hood_angle": "Hood Tilt Angle (°)",
        "param_roof_arc": "Roof Arc Factor",
        "param_windshield": "Windshield Angle (°)",
        "param_rear_window": "Rear Window Angle (°)",
        "param_wheel_arch": "Wheel Arch Bulge (m)",
        "param_waistline": "Waistline Height Ratio",
        "generate_btn": "Generate Surfaces",
        "optimize_btn": "AI Optimise",
        "reset_btn": "Reset Params",
        "quality_title": "Surface Quality Report",
        "quality_g0": "G0 Continuity",
        "quality_g1": "G1 Continuity",
        "quality_g2": "G2 Continuity",
        "quality_fairness": "Fairness",
        "quality_overall": "Overall Score",
        "quality_notes": "Notes",
        "opt_before": "Before Optimisation",
        "opt_after": "After Optimisation",
        "opt_params_title": "Parameter Comparison",
        "opt_quality_title": "Quality Comparison",
        "surface_side": "Side Panel",
        "surface_top": "Top Panel",
        "surface_hood": "Hood Panel",
        "fullcar_title": "Full Car 3D View",
        "fullcar_fallback": "Full-car module unavailable, switched to merged 3-panel view",
        "fullcar_parts_count": "Parts",
        "fullcar_vertices": "Vertices",
        "fullcar_faces": "Faces",
        "no_data": "Click 'Generate Surfaces' first",
        "stats_title": "Statistics",
    },
}


def t(key: str) -> str:
    """Return translated text for the current language."""
    lang = st.session_state.get("lang", "zh")
    return I18N.get(lang, I18N["zh"]).get(key, key)


# ===================================================================
# Enhanced control-point generators
# Produces more realistic car-like surface shapes.
# ===================================================================

def enhanced_side_panel_ctrl(params) -> np.ndarray:
    """
    Build control points for a realistic side panel.
    Features:
      - Wheel arch depressions at front and rear axle positions
      - Waistline ridge (subtle bulge along the character line)
      - Slight tumble-home (upper body inward lean)
    """
    p = params
    nu, nv = 7, 5
    ctrl = np.zeros((nu, nv, 3))

    half_l = p.length / 2
    half_h = p.height
    y_pos = p.width / 2
    wl_z = p.height * p.waistline_ratio
    wr = p.wheel_radius

    front_axle_x = p.wheelbase / 2
    rear_axle_x = -p.wheelbase / 2

    for i in range(nu):
        for j in range(nv):
            u = i / (nu - 1)  # 0..1 along length
            v = j / (nv - 1)  # 0..1 along height
            x = -half_l + p.length * u

            # Base y at waistline level with slight tumble-home
            tumble_home = 0.02 * v  # upper body leans inward
            y = y_pos - tumble_home

            # Wheel arch depressions — pull surface inward near axle positions
            for axle_x in [front_axle_x, rear_axle_x]:
                dx = abs(x - axle_x)
                arch_half_w = p.wheel_radius * 1.3
                if dx < arch_half_w and v * half_h < wr * 1.6:
                    arch_depth = (1 - dx / arch_half_w) * p.wheel_arch_bulge * (1 - v * half_h / (wr * 1.6))
                    y -= arch_depth * 0.5

            # Waistline ridge — slight outward bulge at waistline height
            dist_to_wl = abs(v * half_h - wl_z)
            if dist_to_wl < 0.08:
                ridge = 0.012 * (1 - dist_to_wl / 0.08)
                y += ridge

            ctrl[i, j, 0] = x
            ctrl[i, j, 1] = y
            ctrl[i, j, 2] = half_h * v

    return ctrl


def enhanced_top_panel_ctrl(params) -> np.ndarray:
    """
    Build control points for a realistic roof / top panel.
    Features:
      - Smooth arc from windshield header to rear window header
      - Slight crown (cross-car curvature) for stiffness
      - Transition from higher windshield edge to lower rear edge
    """
    p = params
    nu, nv = 7, 5
    ctrl = np.zeros((nu, nv, 3))

    half_l = p.length / 2
    base_z = p.height * p.waistline_ratio

    # Windshield header and rear window header positions along x
    ws_header_x = p.wheelbase / 2 - 0.2
    rw_header_x = -p.wheelbase / 2 + 0.3

    for i in range(nu):
        for j in range(nv):
            u = i / (nu - 1)
            v = j / (nv - 1)
            x = -half_l + p.length * u
            y = -p.width / 2 + p.width * v

            # Longitudinal arc: highest near centre, drops at front (windshield) and rear
            if x > ws_header_x:
                # Front slope — windshield drop
                drop_front = (x - ws_header_x) * np.tan(np.radians(p.windshield_angle)) * 0.6
                z = base_z + p.height * (1 - p.waistline_ratio) * p.roof_arc - drop_front
            elif x < rw_header_x:
                # Rear slope — rear window drop
                drop_rear = (rw_header_x - x) * np.tan(np.radians(p.rear_window_angle)) * 0.4
                z = base_z + p.height * (1 - p.waistline_ratio) * p.roof_arc - drop_rear
            else:
                # Main roof — apply arc
                centre_x = (ws_header_x + rw_header_x) / 2
                span = (ws_header_x - rw_header_x) / 2
                if span > 0:
                    arc_factor = 1 - ((x - centre_x) / span) ** 2
                else:
                    arc_factor = 0
                z = base_z + p.height * (1 - p.waistline_ratio) * (p.roof_arc * 0.3 + 0.7 * arc_factor * p.roof_arc)

            # Cross-car crown — slight upward bow
            v_centre = 0.5
            crown = 0.015 * (1 - (2 * (v - v_centre)) ** 2)
            z += crown

            ctrl[i, j, 0] = x
            ctrl[i, j, 1] = y
            ctrl[i, j, 2] = z

    return ctrl


def enhanced_hood_ctrl(params) -> np.ndarray:
    """
    Build control points for a realistic hood panel.
    Features:
      - Front edge dips down (following hood tilt angle)
      - Central power-bulge (subtle rise along the centreline)
      - Slight taper towards the front
    """
    p = params
    nu, nv = 6, 5
    ctrl = np.zeros((nu, nv, 3))

    front_axle_x = p.wheelbase / 2
    hood_start_x = front_axle_x - 0.15
    hood_end_x = hood_start_x + p.front_overhang
    base_z = p.height * p.waistline_ratio + 0.04

    for i in range(nu):
        for j in range(nv):
            u = i / (nu - 1)  # 0=rear edge, 1=front tip
            v = j / (nv - 1)  # 0=left, 1=right
            x = hood_start_x + (hood_end_x - hood_start_x) * u

            # Front dip — linear drop based on hood angle
            dip = u * (hood_end_x - hood_start_x) * np.tan(np.radians(p.hood_angle)) * 0.5

            # Central power bulge — subtle rise along v=0.5 line
            v_off = abs(v - 0.5)
            bulge = 0.02 * (1 - (2 * v_off) ** 2) * (1 - u)  # fades towards front

            # Taper — width narrows slightly towards front
            taper = 1 - 0.08 * u
            y = -p.width / 2 * taper + p.width * taper * v

            z = base_z - dip + bulge

            ctrl[i, j, 0] = x
            ctrl[i, j, 1] = y
            ctrl[i, j, 2] = z

    return ctrl


# ===================================================================
# Helper: Plotly mesh3d from trimesh
# ===================================================================

def trimesh_to_plotly(mesh, name: str = "mesh", color: str = "steelblue",
                      opacity: float = 0.85) -> go.Mesh3d:
    """Convert a trimesh.Trimesh to a Plotly mesh3d trace."""
    verts = mesh.vertices
    faces = mesh.faces
    return go.Mesh3d(
        x=verts[:, 0],
        y=verts[:, 1],
        z=verts[:, 2],
        i=faces[:, 0],
        j=faces[:, 1],
        k=faces[:, 2],
        name=name,
        color=color,
        opacity=opacity,
        flatshading=True,
    )


def surface_dict_to_plotly(surf: dict, name: str = "surface",
                           color: str = "royalblue", opacity: float = 0.8) -> go.Mesh3d:
    """Convert a surface dict {vertices, faces} to a Plotly mesh3d trace."""
    verts = surf["vertices"]
    faces = surf["faces"]
    return go.Mesh3d(
        x=verts[:, 0],
        y=verts[:, 1],
        z=verts[:, 2],
        i=faces[:, 0],
        j=faces[:, 1],
        k=faces[:, 2],
        name=name,
        color=color,
        opacity=opacity,
        flatshading=True,
    )


def _3d_layout(title: str = "") -> go.Layout:
    """Return a standard 3D layout with equal aspect ratio and rotation enabled."""
    return go.Layout(
        title=title,
        scene=dict(
            aspectmode="data",
            xaxis=dict(title="X (m)"),
            yaxis=dict(title="Y (m)"),
            zaxis=dict(title="Z (m)"),
            camera=dict(eye=dict(x=1.8, y=1.8, z=1.2)),
        ),
        margin=dict(l=0, r=0, t=40, b=0),
        height=600,
    )


# ===================================================================
# Surface generation with enhanced control points
# ===================================================================

def generate_enhanced_surfaces(params) -> Dict[str, dict]:
    """
    Generate three car surfaces using enhanced control-point builders.
    Falls back to the original builders on error.
    """
    from core.car_surface import bezier_surface_vec as _bev, _make_faces

    builders = {
        "side": enhanced_side_panel_ctrl,
        "top": enhanced_top_panel_ctrl,
        "hood": enhanced_hood_ctrl,
    }
    result = {}
    for name, builder in builders.items():
        try:
            ctrl = builder(params)
            verts = _bev(ctrl, params.surface_u, params.surface_v)
            faces = _make_faces(params.surface_u, params.surface_v)
        except Exception:
            # Fallback to original builders
            fallback = {"side": build_side_panel_ctrl,
                        "top": build_top_panel_ctrl,
                        "hood": build_hood_ctrl}
            ctrl = fallback[name](params)
            verts = _bev(ctrl, params.surface_u, params.surface_v)
            faces = _make_faces(params.surface_u, params.surface_v)
        result[name] = {"vertices": verts, "faces": faces}
    return result


# ===================================================================
# Full-car mesh building
# ===================================================================

def build_full_car_mesh(params) -> Optional["trimesh.Trimesh"]:
    """
    Build a full-car trimesh using the assembler module.
    Returns None if assembler is unavailable.
    """
    if not _HAS_ASSEMBLER:
        return None
    try:
        full_params = FullCarParams(
            length=params.length,
            width=params.width,
            height=params.height,
            wheelbase=params.wheelbase,
            front_overhang=params.front_overhang,
            rear_overhang=params.rear_overhang,
            hood_angle=params.hood_angle,
            roof_arc=params.roof_arc,
            windshield_angle=params.windshield_angle,
            rear_window_angle=params.rear_window_angle,
            wheel_arch_bulge=params.wheel_arch_bulge,
            waistline_ratio=params.waistline_ratio,
            wheel_radius=params.wheel_radius,
            surface_u=params.surface_u,
            surface_v=params.surface_v,
        )
        parts = build_full_car(full_params)
        merged = merge_all(parts)
        return merged
    except Exception:
        return None


# ===================================================================
# Parameter widget helpers
# ===================================================================

def _slider(label_key: str, min_val: float, max_val: float, default: float,
            step: float = 0.01, fmt: str = "%.2f") -> float:
    """Render a Streamlit slider with i18n label."""
    return st.sidebar.slider(t(label_key), min_val, max_val, default, step, format=fmt)


def read_params_from_sidebar() -> CoreCarParams:
    """Read all car parameters from sidebar sliders and return a CoreCarParams."""
    length = _slider("param_length", 3.5, 6.0, 4.7, 0.05, "%.2f")
    width = _slider("param_width", 1.5, 2.3, 1.85, 0.01, "%.2f")
    height = _slider("param_height", 1.1, 2.1, 1.45, 0.01, "%.2f")
    wheelbase = _slider("param_wheelbase", 2.0, 3.5, 2.7, 0.05, "%.2f")
    hood_angle = _slider("param_hood_angle", 0.0, 35.0, 15.0, 0.5, "%.1f")
    roof_arc = _slider("param_roof_arc", 0.0, 1.5, 0.5, 0.01, "%.2f")
    windshield = _slider("param_windshield", 15.0, 45.0, 28.0, 0.5, "%.1f")
    rear_window = _slider("param_rear_window", 10.0, 40.0, 25.0, 0.5, "%.1f")
    wheel_arch = _slider("param_wheel_arch", 0.0, 0.4, 0.15, 0.01, "%.2f")
    waistline = _slider("param_waistline", 0.5, 0.95, 0.75, 0.01, "%.2f")

    # Derive overhangs from length & wheelbase
    total_oh = length - wheelbase
    front_oh = round(total_oh * 0.45, 3)
    rear_oh = round(total_oh - front_oh, 3)

    return CoreCarParams(
        length=length,
        width=width,
        height=height,
        wheelbase=wheelbase,
        front_overhang=front_oh,
        rear_overhang=rear_oh,
        hood_angle=hood_angle,
        roof_arc=roof_arc,
        windshield_angle=windshield,
        rear_window_angle=rear_window,
        wheel_arch_bulge=wheel_arch,
        waistline_ratio=waistline,
    )


# ===================================================================
# Tab renderers
# ===================================================================

def render_3d_tab(params: CoreCarParams, surfaces: Optional[Dict[str, dict]]):
    """Render the 3D View tab with two sub-tabs: Panel Surfaces & Full Car."""
    sub_tabs = st.tabs([t("subtab_surface"), t("subtab_fullcar")])

    # --- Sub-tab: Panel Surfaces ---
    with sub_tabs[0]:
        if surfaces is None:
            st.info(t("no_data"))
            return

        surface_colors = {
            "side": ("surface_side", "#4A90D9"),
            "top": ("surface_top", "#50C878"),
            "hood": ("surface_hood", "#E8A838"),
        }
        traces = []
        for key, (label_key, color) in surface_colors.items():
            if key in surfaces:
                traces.append(surface_dict_to_plotly(
                    surfaces[key], name=t(label_key), color=color, opacity=0.85
                ))
        fig = go.Figure(data=traces, layout=_3d_layout(t("app_title")))
        st.plotly_chart(fig, use_container_width=True)

        # Surface statistics
        with st.expander(t("stats_title")):
            for key in surfaces:
                v_count = len(surfaces[key]["vertices"])
                f_count = len(surfaces[key]["faces"])
                st.write(f"**{t('surface_' + key if key != 'hood' else 'surface_hood')}**: "
                         f"{v_count} vertices, {f_count} faces")

    # --- Sub-tab: Full Car ---
    with sub_tabs[1]:
        full_car_mesh = build_full_car_mesh(params)
        if full_car_mesh is not None:
            fig_full = go.Figure(
                data=[trimesh_to_plotly(full_car_mesh, name=t("fullcar_title"),
                                        color="#708090", opacity=0.9)],
                layout=_3d_layout(t("fullcar_title")),
            )
            st.plotly_chart(fig_full, use_container_width=True)

            # Statistics
            col1, col2, col3 = st.columns(3)
            col1.metric(t("fullcar_vertices"), f"{len(full_car_mesh.vertices)}")
            col2.metric(t("fullcar_faces"), f"{len(full_car_mesh.faces)}")
            try:
                parts = build_full_car(FullCarParams(
                    length=params.length, width=params.width, height=params.height,
                    wheelbase=params.wheelbase,
                    front_overhang=params.front_overhang,
                    rear_overhang=params.rear_overhang,
                    hood_angle=params.hood_angle,
                    roof_arc=params.roof_arc,
                    windshield_angle=params.windshield_angle,
                    rear_window_angle=params.rear_window_angle,
                    wheel_arch_bulge=params.wheel_arch_bulge,
                    waistline_ratio=params.waistline_ratio,
                ))
                col3.metric(t("fullcar_parts_count"), f"{len(parts)}")
            except Exception:
                col3.metric(t("fullcar_parts_count"), "—")
        else:
            # Fallback: merge the three panel surfaces
            st.warning(t("fullcar_fallback"))
            if surfaces is not None:
                traces_fb = []
                for key, (label_key, color) in [
                    ("side", ("surface_side", "#4A90D9")),
                    ("top", ("surface_top", "#50C878")),
                    ("hood", ("surface_hood", "#E8A838")),
                ]:
                    if key in surfaces:
                        traces_fb.append(surface_dict_to_plotly(
                            surfaces[key], name=t(label_key), color=color, opacity=0.85
                        ))
                fig_fb = go.Figure(data=traces_fb, layout=_3d_layout(t("fullcar_title")))
                st.plotly_chart(fig_fb, use_container_width=True)
            else:
                st.info(t("no_data"))


def render_optimisation_tab(params: CoreCarParams,
                            surfaces: Optional[Dict[str, dict]]):
    """Render the Optimisation Comparison tab."""
    if surfaces is None:
        st.info(t("no_data"))
        return

    if st.button(t("optimize_btn"), key="opt_btn"):
        with st.spinner("AI optimising..." if st.session_state.get("lang", "zh") == "zh"
                        else "AI optimising..."):
            opt_params, opt_surfaces, opt_report = ai_optimize_surface(params, surfaces)
        st.session_state["opt_params"] = opt_params
        st.session_state["opt_surfaces"] = opt_surfaces
        st.session_state["opt_report"] = opt_report

    opt_surfaces = st.session_state.get("opt_surfaces")
    opt_report = st.session_state.get("opt_report")
    opt_params = st.session_state.get("opt_params")

    if opt_surfaces is None:
        return

    # --- Parameter comparison ---
    st.subheader(t("opt_params_title"))
    orig_report = assess_quality(surfaces)

    col_before, col_after = st.columns(2)
    param_fields = [
        ("length", "param_length"), ("width", "param_width"),
        ("height", "param_height"), ("wheelbase", "param_wheelbase"),
        ("hood_angle", "param_hood_angle"), ("roof_arc", "param_roof_arc"),
        ("windshield_angle", "param_windshield"),
        ("rear_window_angle", "param_rear_window"),
        ("wheel_arch_bulge", "param_wheel_arch"),
        ("waistline_ratio", "param_waistline"),
    ]

    with col_before:
        st.markdown(f"**{t('opt_before')}**")
        for attr, label_key in param_fields:
            val = getattr(params, attr, "—")
            st.write(f"{t(label_key)}: {val}")

    with col_after:
        st.markdown(f"**{t('opt_after')}**")
        for attr, label_key in param_fields:
            val = getattr(opt_params, attr, "—")
            st.write(f"{t(label_key)}: {val}")

    # --- Quality comparison ---
    st.subheader(t("opt_quality_title"))
    quality_fields = [
        ("g0_continuity", "quality_g0"),
        ("g1_continuity", "quality_g1"),
        ("g2_continuity", "quality_g2"),
        ("fairness", "quality_fairness"),
        ("overall_score", "quality_overall"),
    ]

    col_q1, col_q2 = st.columns(2)
    with col_q1:
        st.markdown(f"**{t('opt_before')}**")
        for attr, label_key in quality_fields:
            val = getattr(orig_report, attr, 0)
            st.progress(min(val, 1.0), text=f"{t(label_key)}: {val:.3f}")

    with col_q2:
        st.markdown(f"**{t('opt_after')}**")
        for attr, label_key in quality_fields:
            val = getattr(opt_report, attr, 0)
            st.progress(min(val, 1.0), text=f"{t(label_key)}: {val:.3f}")

    # --- 3D comparison ---
    surface_colors = {
        "side": "#4A90D9", "top": "#50C878", "hood": "#E8A838"
    }
    col_3d1, col_3d2 = st.columns(2)

    with col_3d1:
        traces_before = []
        for key, color in surface_colors.items():
            if key in surfaces:
                traces_before.append(surface_dict_to_plotly(
                    surfaces[key], name=key, color=color, opacity=0.8))
        fig_before = go.Figure(data=traces_before, layout=_3d_layout(t("opt_before")))
        st.plotly_chart(fig_before, use_container_width=True)

    with col_3d2:
        traces_after = []
        for key, color in surface_colors.items():
            if key in opt_surfaces:
                traces_after.append(surface_dict_to_plotly(
                    opt_surfaces[key], name=key, color=color, opacity=0.8))
        fig_after = go.Figure(data=traces_after, layout=_3d_layout(t("opt_after")))
        st.plotly_chart(fig_after, use_container_width=True)


def render_quality_tab(surfaces: Optional[Dict[str, dict]]):
    """Render the Quality Analysis tab."""
    if surfaces is None:
        st.info(t("no_data"))
        return

    report = assess_quality(surfaces)

    st.subheader(t("quality_title"))

    # Radar chart
    categories = [
        t("quality_g0"), t("quality_g1"), t("quality_g2"),
        t("quality_fairness"), t("quality_overall"),
    ]
    values = [
        report.g0_continuity, report.g1_continuity, report.g2_continuity,
        report.fairness, report.overall_score,
    ]
    # Close the radar loop
    categories_closed = categories + [categories[0]]
    values_closed = values + [values[0]]

    fig_radar = go.Figure(data=go.Scatterpolar(
        r=values_closed,
        theta=categories_closed,
        fill="toself",
        name=t("quality_title"),
    ))
    fig_radar.update_layout(
        polar=dict(radialaxis=dict(visible=True, range=[0, 1])),
        showlegend=False,
        height=450,
    )
    st.plotly_chart(fig_radar, use_container_width=True)

    # Detailed metrics
    quality_fields = [
        ("g0_continuity", "quality_g0"),
        ("g1_continuity", "quality_g1"),
        ("g2_continuity", "quality_g2"),
        ("fairness", "quality_fairness"),
        ("overall_score", "quality_overall"),
    ]
    for attr, label_key in quality_fields:
        val = getattr(report, attr, 0)
        st.progress(min(val, 1.0), text=f"{t(label_key)}: {val:.4f}")

    if report.notes:
        st.info(f"**{t('quality_notes')}**: {report.notes}")


# ===================================================================
# Main application
# ===================================================================

def main():
    """Entry point for the Streamlit application."""

    # --- Page config ---
    st.set_page_config(
        page_title="EVOLUTION AI DEMO",
        page_icon="🚗",
        layout="wide",
    )

    # --- Language selector (persisted in session_state) ---
    if "lang" not in st.session_state:
        st.session_state["lang"] = "zh"

    lang_col, _ = st.columns([1, 5])
    with lang_col:
        lang_choice = st.selectbox(
            t("lang_label"),
            options=["zh", "en"],
            index=0 if st.session_state["lang"] == "zh" else 1,
            key="lang_selector",
        )
        st.session_state["lang"] = lang_choice

    # --- Title ---
    st.title(t("app_title"))

    # --- Sidebar: Parameters ---
    st.sidebar.header(t("param_section"))
    params = read_params_from_sidebar()

    # --- Action buttons ---
    col_gen, col_opt, col_rst = st.sidebar.columns(3)
    generate_clicked = col_gen.button(t("generate_btn"), key="gen_btn_sidebar")
    reset_clicked = col_rst.button(t("reset_btn"), key="rst_btn_sidebar")

    if reset_clicked:
        for k in list(st.session_state.keys()):
            if k not in ("lang", "lang_selector"):
                del st.session_state[k]
        st.rerun()

    # --- Generate surfaces ---
    if generate_clicked or "surfaces" in st.session_state:
        if generate_clicked:
            with st.spinner("Generating..." if st.session_state["lang"] == "en" else "生成中..."):
                st.session_state["surfaces"] = generate_enhanced_surfaces(params)
                st.session_state["params_snapshot"] = copy.deepcopy(params)
                # Clear stale optimisation data
                for k in ("opt_params", "opt_surfaces", "opt_report"):
                    st.session_state.pop(k, None)

        surfaces = st.session_state.get("surfaces")
        active_params = st.session_state.get("params_snapshot", params)
    else:
        surfaces = None
        active_params = params

    # --- Tabs ---
    tab_3d, tab_opt, tab_quality = st.tabs([
        t("tab_3d"), t("tab_opt"), t("tab_quality")
    ])

    with tab_3d:
        render_3d_tab(active_params, surfaces)

    with tab_opt:
        render_optimisation_tab(active_params, surfaces)

    with tab_quality:
        render_quality_tab(surfaces)


# ===================================================================
# Entry point
# ===================================================================
if __name__ == "__main__":
    main()
