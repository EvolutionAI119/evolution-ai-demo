@echo off
chcp 65001 >nul
echo ============================================
echo  EVOLUTION AI — Plotly/Streamlit 版本修复
echo ============================================
echo.

echo [1/3] 降级 Plotly 到 5.24.0（兼容 Streamlit 1.57.0）...
python -m pip install "plotly==5.24.0" --force-reinstall

echo.
echo [2/3] 验证版本...
python -c "import plotly; print(f'Plotly: {plotly.__version__}'); import streamlit; print(f'Streamlit: {streamlit.__version__}')"

echo.
echo [3/3] 重启 Streamlit...
echo 请在另一个命令行窗口执行: streamlit run app.py
echo.
echo 修复完成！
pause
